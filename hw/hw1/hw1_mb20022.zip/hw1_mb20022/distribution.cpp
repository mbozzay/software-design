// Function to fill a QVector with samples from a specified distribution
// must #include <random> to use this function
//

